<?php
    if(!isset($_SESSION))
    {
        session_start();
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="js/bootstrap.min.js">
    <title>Onlineshop</title>
</head>
<body>
    <nav class="navbar navbar-light bg-light justify-content-between">
        <a class="navbar-brand">Online Shop</a>
        <div class="float-left">
            <?php
            //
                if(isset($_SESSION['benutzertyp'])){
                    if($_SESSION['benutzertyp']=="admin") {
                        echo '<a href="benutzeruebersicht.php" class="float-left btn btn-outline-dark">Benutzerübersicht</a>';
                        echo '<a href="produkt_erstellen.php" class="float-left btn btn-outline-success">Produkt hinzufügen</a>';
                    }else{
                        echo '<a href="warenkorb.php" class="float-left btn btn-outline-success">Warenkorb</a>';
                    }
                    echo '<a href="logout.php" class="float-left btn btn-outline-danger">Logout</a>';

                }else{
                    echo '<a href="login.php" class="float-left btn btn-outline-success">Login</a>';
                    echo '<a href="warenkorb.php" class="float-left btn btn-outline-success">Warenkorb</a>';
                }
            ?>
        </div>

        <!-- Suche -->
        <form class="form-inline" method="post">
            <input class="form-control mr-sm-2" type="search" placeholder="" name="search">
            <button class="btn btn-outline-info my-2 my-sm-0" type="submit">Suchen</button>
        </form>
    </nav>
    <?php
        include("produkteliste.php")
    ?>
</body>
</html>