<?php
    session_start();
    $id = $_GET['id'];
    $existiert = false;
    if(isset($_SESSION['warenkorb'] )){
        foreach ($_SESSION['warenkorb'] as $produktSchlüssel => $produktWerte) {
            if ($produktWerte[0] == $id) {
                $_SESSION['warenkorb'][$produktSchlüssel][1]++;
                $existiert = true;
            }
        }
        if($existiert==false){
            $_SESSION['warenkorb'][] = [$id,1];
        }
    }else{
        $_SESSION['warenkorb'][] = [$id,1];
    }


    
    header('Location: shop.php');
