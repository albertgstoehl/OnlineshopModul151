<?php
    define('MYSQL_HOST',"10.5.0.7");  
    define('MYSQL_USER',"root");  
    define('MYSQL_PW',"test");
    define('MYSQL_DB',"onlineshop");

    $conn = new mysqli(MYSQL_HOST, MYSQL_USER, MYSQL_PW, MYSQL_DB); 
    
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
?>
